package com.dbestech.online_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
